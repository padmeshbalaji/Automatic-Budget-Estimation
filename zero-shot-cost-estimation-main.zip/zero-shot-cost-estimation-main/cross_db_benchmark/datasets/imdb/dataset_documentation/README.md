# Dataset Documentation

Schema was restricted to be acyclic such that Naru can be applied seamlessly. Also, we added the column names in the
script.py