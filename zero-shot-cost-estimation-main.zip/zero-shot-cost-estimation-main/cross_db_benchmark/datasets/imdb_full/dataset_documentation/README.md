# Dataset Documentation

This dataset contains all tables of the imdb schema.